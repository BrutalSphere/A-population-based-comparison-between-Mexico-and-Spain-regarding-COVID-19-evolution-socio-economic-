library(dplyr)
data_españa <- read.csv('C:/Users/Lexin Zhou/Downloads/casos_hosp_uci_def_sexo_edad_provres.csv', sep = ';')
fun <- function(x) {
  sum(x)
}
data <- data_españa
resul <- list()
vars <- c('num_casos', 'num_hosp', 'num_uci', 'num_def')
#num_casos
df1 <- data %>%
  group_by(provincia_iso) %>%
  mutate(Data = fun(num_casos))

df1 <- distinct(df1, provincia_iso, .keep_all = TRUE) %>%   # for dplyr >= 0.5.0
  arrange(desc(Data))
df1 <- df1[order(df1$provincia_iso),]

#num_hosp
df2 <- data %>%
  group_by(provincia_iso) %>%
  mutate(Data = fun(num_hosp))

df2 <- distinct(df2, provincia_iso, .keep_all = TRUE) %>%   # for dplyr >= 0.5.0
  arrange(desc(Data))
df2 <- df2[order(df2$provincia_iso),]

#num_uci
df3 <- data %>%
  group_by(provincia_iso) %>%
  mutate(Data = fun(num_uci))

df3 <- distinct(df3, provincia_iso, .keep_all = TRUE) %>%   # for dplyr >= 0.5.0
  arrange(desc(Data))
df3 <- df3[order(df3$provincia_iso),]

#num_def
df4 <- data %>%
  group_by(provincia_iso) %>%
  mutate(Data = fun(num_def))

df4 <- distinct(df4, provincia_iso, .keep_all = TRUE) %>%   # for dplyr >= 0.5.0
  arrange(desc(Data))
df4 <- df4[order(df4$provincia_iso),]

new_data <- data.frame('ISO' = df1$provincia_iso, 'num_casos' = df1$Data, 'num_hosp' = df2$Data,
                       'num_uci' = df3$Data, 'num_def' = df4$Data)
new_data <- new_data[1:52,] 
dic <- list('C' = 'ES-GA', 'A' = 'ES-VC', 'AB' = 'ES-CM', 'AL' = 'ES-AN',
            'VI' = 'ES-PV', 'O' = 'ES-AS', 'BA' = 'ES-EX', 'B' = 'ES-CT',
            'BI' = 'ES-PV', 'BU' = 'ES-CL', 'S' = 'ES-CB', 'CS' = 'ES-VC',
            'CE' = 'ES-CE', 'CR' = 'ES-CM', 'CU' = 'ES-CM', 'CC' = 'ES-EX', 'CA' = 'ES-AN',
            'CO' = 'ES-AN', 'SS' = 'ES-PV', 'GI' = 'ES-CT', 'GR' = 'ES-AN',
            'GU' = 'ES-CM', 'H' = 'ES-AN', 'HU' = 'ES-AR', 'PM' = 'ES-IB',
            'J' = 'ES-AN', 'LO' = 'ES-RI', 'GC' = 'ES-CN', 'LE' = 'ES-CL',
            'ML' = 'ES-ML', 'NC'='ES-NC',
            'L' = 'ES-CT', 'LU' = 'ES-GA', 'M' = 'ES-MD', 'MU' = 'ES-MC',
            'MA' = 'ES-AN', 'NA' = 'ES-NC', 'OR' = 'ES-GA', 'P' = 'ES-CL',
            'PO' = 'ES-GA', 'SA' = 'ES-CL', 'TF' = 'ES-CN', 'SG' = 'ES-CL',
            'SE' = 'ES-AN', 'SO' = 'ES-CL', 'T' = 'ES-CT', 'TE' = 'ES-AR',
            'TO' = 'CM', 'V' = 'ES-VC', 'VA' = 'ES-CL', 'ZA' = 'ES-CL',
            'Z' = 'ES-AR', 'VI' = 'ES-PV', 'AV' = 'ES-CL')
new_data$ISO_comunidad <- seq(1:52)

for (i in 1:52){
  new_data[i, 'ISO_comunidad']<- dic[[new_data[i, 'ISO']]]
}

new_data$per_hosp <- new_data$num_hosp/new_data$num_casos * 100
new_data$per_uci <- new_data$num_uci/new_data$num_casos * 100
new_data$per_def <- new_data$num_def/new_data$num_casos * 100

### Since the rows are province-level data, we now turn them into community-level data


df1 = new_data
df = aggregate(x = df1[,c("num_hosp", "num_uci", "num_def", "num_casos")],                # Specify data column
          by = list(df1$ISO_comunidad),              # Specify group indicator
          FUN = sum)
df$per_hosp = df$num_hosp/df$num_casos
df$per_uci = df$num_uci/df$num_casos
df$per_def = df$num_def/df$num_casos
write.csv(df,file = "datos_clinicos_espanaCorregidos.csv")

