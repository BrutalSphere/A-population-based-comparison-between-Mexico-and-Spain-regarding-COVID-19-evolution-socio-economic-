archivo = read.csv('C:/Users/User/Desktop/Proyecto_II/210220COVID19MEXICO.csv', header= TRUE, sep = ',',dec='.',encoding= 'utf-8' )
"Se carga el csv que contiene los datos a analizar en una variable dentro de R 
"

library(plyr)
library(dplyr)

"Importamos la librería plyr ya que hemos hecho uso de la función revalue propia de la librería
de forma anecdotica para saber utilizarla en el futuro "

df = archivo[(archivo$RESULTADO_LAB==1),]

"Se filtrán tan solo los casos en los que el laboratorio ha confirmado el positivo en SARS-COVID; descartando negativos,
resultados no concluyentes e individuos a los que no se ha realizado pruebas.
"

df1 = df[!(df$ASMA>2|df$EPOC>2|df$DIABETES>2|df$INMUSUPR>2|df$HIPERTENSION>2|df$OTRA_COM>2|df$CARDIOVASCULAR>2|df$OBESIDAD>2|df$RENAL_CRONICA>2|df$TABAQUISMO>2|df$UCI>97|df$NEUMONIA>2|df$INTUBADO>97|df$EMBARAZO>97),]

"Debido a que tenemos una muestra de gran tamaño, desechamos los individuos con datos faltantes en variables que 
consideramos de gran importancia. Generalmente estas variables indican la presencia de embarazo, complicaciones medicas u
otras enfermedades
"

df1$FECHA_DEF = revalue(df1$FECHA_DEF, c("9999-99-99"=NA))

"Los individuos que no han fallecido presentan está variable(fecha) como faltante con un formato 9999-99-99; como este
formato es dificil de tratar creemos conveniente convertirlos a datos faltantes o NA
"

df1$FECHA_DEF = as.Date(df1$FECHA_DEF, format="%Y-%m-%d")
df1$FECHA_INGRESO = as.Date(df1$FECHA_INGRESO, format="%Y-%m-%d")
df1$FECHA_SINTOMAS = as.Date(df1$FECHA_SINTOMAS, format="%Y-%m-%d")
df1$FECHA_ACTUALIZACION = as.Date(df1$FECHA_ACTUALIZACION, format="%Y-%m-%d")

"Convertimos los datos a tipo fecha para poder realizar las operaciones básicas para nuestras variables calculadas
"

df2 = df1[(df1$FECHA_DEF>=df1$FECHA_INGRESO&df1$FECHA_DEF>=df1$FECHA_SINTOMAS|is.na(df1$FECHA_DEF)),]

"Eliminamos posibles errores de registros: gente que ha muerto antes de ser ingresada o gente que ha muerto antes 
de tener sintomas
"

df3 = df2[(df2$FECHA_SINTOMAS<=as.Date('15-1-2021',format="%d-%m-%Y" )),]

"Debido a que queremos los registros de la segunda ola, en mexico, cogemos datos a partir del 1-10-2020; 
y por motivos clinicos cogemos pacientes que hayan sido registrados a 5 semanas previas de la última 
actualización de la base.	
La razón de 5 semanas es que un 98% de pacientes con síntomas fallecen dentro de un margen 35 dias, 
eliminando esos pacientes no se distorsiona al hacer análisis sobre la mortalidad.

"
df3$SUPERVIVENCIA_DIAS = as.numeric(difftime(df3$FECHA_DEF, df3$FECHA_SINTOMAS, units = "days")) # days
df3$FALLECIMIENTO = ifelse(is.na(df3$SUPERVIVENCIA_DIAS), 0, 1)
df3$OSURVIVAL15 = ifelse(df3$SUPERVIVENCIA_DIAS>=15|is.na(df3$SUPERVIVENCIA_DIAS), 1, 0)
df3$OSURVIVAL30 = ifelse(df3$SUPERVIVENCIA_DIAS>=30|is.na(df3$SUPERVIVENCIA_DIAS), 1, 0)
df3$SINTOMAS_HOSPITAL = as.numeric(difftime(df3$FECHA_INGRESO, df3$FECHA_SINTOMAS, units = "days"))

"
Aquí se realiza el calculo de las variables calculadas. En este orden: días de supervivencia, si ha fallecido, 
si ha sobrevivido al menos 15 días, si ha sobrevivido al menos 30 días y días que tardo en ir al hospital tras presentar síntomas
"


df3$ENTIDAD_UM = mapvalues(df3$ENTIDAD_UM,from = c(1:32,36), to =c( "AGUASCALIENTES",'BAJA CALIFORNIA','BAJA CALIFORNIA SUR','CAMPECHE','COAHUILA DE ZARAGOZA',
                                                                    'COLIMA','CHIAPAS','CHIHUAHUA','MEXICO CITY','DURANGO','GUANAJUATO','GUERRERO',
                                                                    'HIDALGO','JALISCO','STATE OF MEXICO','MICHOACÁN DE OCAMPO','MORELOS','NAYARIT','NUEVO LEÓN',
                                                                    'OAXACA','PUEBLA','QUERÉTARO','QUINTANA ROO','SAN LUIS POTOSÍ','SINALOA','SONORA',
                                                                    'TABASCO','TAMAULIPAS','TLAXCALA','VERACRUZ','YUCATÁN','ZACATECAS',
                                                                    'UNITED MEXICAN STATES'))
df3$SECTOR = mapvalues(df3$SECTOR,from = c(1:13,99), to =c('RED CROSS',  'DIF', 'STATE', 'IMSS', 'IMSS-BIENESTAR', 'ISSSTE', 'MUNICIPAL', 
                                                           'PEMEX', 'PRIVATE', 'SEDENA', 'SEMAR', 'SSA', 'UNIVERSITARY', NA))

"
asdasd
"

df3$HOSPITAL = ifelse(df3$TIPO_PACIENTE==2,1,0)
df3$UCI = ifelse(df3$UCI==1,1,0)
df3$INTUBADO = ifelse(df3$INTUBADO==1,1,0)
df3$TIPO_PACIENTE = mapvalues(df3$TIPO_PACIENTE, from = c(1,2,99), to = c( "AMBULATORIO","HOSPITALIZADO",NA))
df3$NEUMONIA = ifelse(df3$NEUMONIA==1,1,0)
df3$EMBARAZO = ifelse(df3$EMBARAZO==1,1,0)
df3$DIABETES = ifelse(df3$DIABETES==1,1,0)
df3$EPOC = ifelse(df3$EPOC==1,1,0)
df3$ASMA = ifelse(df3$ASMA==1,1,0)
df3$INMUSUPR = ifelse(df3$INMUSUPR==1,1,0)
df3$HIPERTENSION = ifelse(df3$HIPERTENSION==1,1,0)
df3$OTRA_COM =  ifelse(df3$OTRA_COM==1,1,0)
df3$CARDIOVASCULAR = ifelse(df3$CARDIOVASCULAR==1,1,0)
df3$OBESIDAD = ifelse(df3$OBESIDAD==1,1,0)
df3$RENAL_CRONICA = ifelse(df3$RENAL_CRONICA==1,1,0)
df3$TABAQUISMO = ifelse(df3$TABAQUISMO==1,1,0)
df3$OTRO_CASO = ifelse(df3$OTRO_CASO==1,1,0)

"
asdasd
"

write.csv2(df3, 'patient_level_data.csv', enc)
ENTIDAD_UM = c()
HOSPITAL = c()
UCI = c()
INTUBADOS = c()
FALLECIDOS = c()
for (i in unique(df3$ENTIDAD_UM)){
  dfs = df3[df3$ENTIDAD_UM==i,]
  ENTIDAD_UM = c(ENTIDAD_UM, i)
  HOSPITAL = c(HOSPITAL,sum(dfs$HOSPITAL))
  UCI = c(UCI,sum(dfs$UCI))
  INTUBADOS = c(INTUBADOS, sum(dfs$INTUBADO))
  FALLECIDOS = c(FALLECIDOS,sum(dfs$FALLECIMIENTO))
}
"
adfssd
"


df4 = data.frame(ENTIDAD_UM, HOSPITAL, UCI, INTUBADOS, FALLECIDOS)
write.csv2(df4, 'agregadosCovid.csv')